package com.fourcatsdev.aula17.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fourcatsdev.aula17.modelo.Endereco;

public interface EnderecoRepository extends JpaRepository<Endereco, Long> {

}
